/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("react"),require("uu5g05-forms")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g04","uu5g05-elements","uu_plus4u5g02","uu_plus4u5g02-app","uu_plus4u5g02-elements","react","uu5g05-forms"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("react"),require("uu5g05-forms")):e.index=t(e[void 0],e.uu5g05,e.uu5g04,e["uu5g05-elements"],e.uu_plus4u5g02,e["uu_plus4u5g02-app"],e["uu_plus4u5g02-elements"],e.react,e["uu5g05-forms"])
}(this,((e,t,r,n,o,i,s,u,a)=>(()=>{var l,c,p,m={938:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});var n=r(94),o=r(12);const i=o.Z.TAG+"Bricks.",s={...o.Z,TAG:i,
Css:n.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_homework_maing01-hi/uu_homework_maing01-hi@0.1.0")}},336:(e,t,r)=>{"use strict";r.d(t,{
ZP:()=>s});var n=r(94);const[o,i]=n.Utils.Context.create(),s=o},12:(e,t,r)=>{"use strict";r.d(t,{Z:()=>i});var n=r(94);const o="UuHomework.",i={TAG:o,
Css:n.Utils.Css.createCssModule(o.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_homework_maing01-hi/uu_homework_maing01-hi@0.1.0")}},640:(e,t,r)=>{"use strict";r.d(t,{
Z:()=>s});var n=r(94),o=r(12);const i=o.Z.TAG+"Core.",s={...o.Z,TAG:i,
Css:n.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_homework_maing01-hi/uu_homework_maing01-hi@0.1.0")}},873:(e,t,r)=>{"use strict";r.d(t,{
Z:()=>m});var n=r(119),o=r.n(n),i=r(94),s=r(781),u=r.n(s),a=r(640),l=r(426),c=r(834),p=r(336);const m=(0,i.createVisualComponent)({uu5Tag:a.Z.TAG+"RouteBar",propTypes:{},defaultProps:{},render(e){
const[,t]=(0,i.useRoute)(),r=[{children:Uu5g05.Utils.Element.create(i.Lsi,{import:l.Z,path:["Menu","shoppingListDetail"]}),onClick:()=>t("shoppingListDetail")}],n=(0,
i.useContext)(p.ZP),s=n.users.map((e=>({children:e.name,onClick:()=>n.changeUser(e.id)})));return Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(u().RouteBar,o()({
appActionList:r},e),Uu5g05.Utils.Element.create(c.Dropdown,{itemList:s,label:n.user.name})))}})},999:(e,t,r)=>{"use strict";r.d(t,{r:()=>o,x:()=>n});const n={id:1,name:"My Shopping List",ownerId:1,
items:[{id:1,name:"Milk",completed:!1},{id:2,name:"Bread",completed:!0}],members:[{id:1,name:"Petr Koller"},{id:2,name:"Jan Novak"},{id:3,name:"Petr Novak"}]},o=[{id:1,name:"Petr Koller Owner"},{id:2,
name:"Jan Novak Member"},{id:3,name:"Petr Novak Member"},{id:4,name:"Jan Koller Other"}]},21:(e,t,r)=>{"use strict";r.r(t),r.d(t,{render:()=>M});var n=r(602),o=r(94),i=(r(918),
r(834)),s=r.n(i),u=r(763),a=r.n(u),l=r(781),c=r.n(l),p=r(640),m=r(923),d=r.n(m),g=r(24),f=r(938);const h=({screenSize:e})=>f.Z.Css.css({display:"flex",maxWidth:624,padding:"24px 0",margin:"0 auto",
flexWrap:"wrap",..."xs"===e?{justifyContent:"center",textAlign:"center"}:null}),U=()=>f.Z.Css.css({padding:"0 24px"}),b=({screenSize:e})=>f.Z.Css.css({flex:1,minWidth:"xs"===e?"100%":0}),k=(0,
o.createVisualComponent)({uu5Tag:f.Z.TAG+"WelcomeRow",propTypes:{left:o.PropTypes.node},defaultProps:{left:void 0},render(e){const{left:t,children:r}=e,[n]=(0,
o.useScreenSize)(),i=o.Utils.VisualComponent.getAttrs(e,h({screenSize:n}));return Uu5g05.Utils.Element.create("div",i,Uu5g05.Utils.Element.create("div",{className:U({screenSize:n})
},t),Uu5g05.Utils.Element.create("div",{className:b({screenSize:n})},r))}});var y=r(873),_=r(426);const v=()=>g.Z.Css.css({fontSize:48,lineHeight:"1em"});let E=(0,o.createVisualComponent)({
uu5Tag:g.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const t={},r=o.Utils.VisualComponent.getAttrs(e)
;return Uu5g05.Utils.Element.create("div",r,Uu5g05.Utils.Element.create(y.Z,null),Uu5g05.Utils.Element.create(k,{left:Uu5g05.Utils.Element.create(d().PersonPhoto,{size:"xl",borderRadius:"none"})
},Uu5g05.Utils.Element.create(s().Text,{category:"story",segment:"heading",type:"h2"},Uu5g05.Utils.Element.create(o.Lsi,{import:_.Z,path:["Home","welcome"]})),t&&Uu5g05.Utils.Element.create(s().Text,{
category:"story",segment:"heading",type:"h2"},t.name)),Uu5g05.Utils.Element.create(k,{left:Uu5g05.Utils.Element.create(s().Icon,{icon:"mdi-human-greeting",className:v()})
},Uu5g05.Utils.Element.create(s().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(o.Lsi,{import:_.Z,path:["Home","intro"]}))),Uu5g05.Utils.Element.create(k,{
left:Uu5g05.Utils.Element.create(s().Icon,{icon:"mdi-monitor",className:v()})},Uu5g05.Utils.Element.create(s().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(o.Lsi,{
import:_.Z,path:["Home","clientSide"]}))),Uu5g05.Utils.Element.create(k,{left:Uu5g05.Utils.Element.create(s().Icon,{icon:"mdi-server",className:v()})},Uu5g05.Utils.Element.create(s().Text,{
category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(o.Lsi,{import:_.Z,path:["Home","serverSide"]}))))}});E=(0,l.withRoute)(E,{authenticated:!1});const w=E,L=f.Z.TAG+"Users.",x={
...f.Z,TAG:L,Css:o.Utils.Css.createCssModule(L.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_homework_maing01-hi/uu_homework_maing01-hi@0.1.0")};var C=r(336),A=r(999)
;const T=(0,o.createComponent)({uu5Tag:x.TAG+"UserProvider",propTypes:{},defaultProps:{},render(e){const[t,r]=(0,o.useState)(A.r[0]),n={user:t,users:A.r,changeUser:e=>{
const t=A.r.find((t=>t.id===e))??A.r[0];r(t)},isOwner:e=>t.id===e,isMember:e=>e.includes(t.id)};return Uu5g05.Utils.Element.create(C.ZP.Provider,{value:n
},"function"==typeof e.children?e.children(jokesDataObject):e.children)}}),P=(o.Utils.Component.lazy((()=>r.e(701).then(r.bind(r,701)))),
o.Utils.Component.lazy((()=>r.e(327).then(r.bind(r,327))))),j=o.Utils.Component.lazy((()=>r.e(180).then(r.bind(r,180)))),S=o.Utils.Component.lazy((()=>r.e(651).then(r.bind(r,651)))),O={"":{
redirect:"shoppingListDetail"},home:e=>Uu5g05.Utils.Element.create(w,e),"sys/uuAppWorkspace/initUve":e=>Uu5g05.Utils.Element.create(P,e),controlPanel:e=>Uu5g05.Utils.Element.create(j,e),
shoppingListDetail:e=>Uu5g05.Utils.Element.create(S,e),"*":()=>Uu5g05.Utils.Element.create(s().Text,{category:"story",segment:"heading",type:"h1"},"Not Found")},Z=(0,o.createVisualComponent)({
uu5Tag:p.Z.TAG+"Spa",propTypes:{},defaultProps:{},render:()=>Uu5g05.Utils.Element.create(a().SpaProvider,{initialLanguageList:["en","cs"]
},Uu5g05.Utils.Element.create(T,null,Uu5g05.Utils.Element.create(s().ModalBus,null,Uu5g05.Utils.Element.create(c().Spa,{routeMap:O}))))});if(o.Environment.appVersion="0.1.0",
!navigator.userAgent.match(/iPhone|iPad|iPod/)){let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}let z;function M(e){z=e,
o.Utils.Dom.render(Uu5g05.Utils.Element.create(n.zj,null,Uu5g05.Utils.Element.create(Z,null)),document.getElementById(e))}},426:(e,t,r)=>{"use strict";r.d(t,{Z:()=>u});var n=r(94),o=r(823)
;const i="uu_homework_maing01-hi",s=e=>r(394)(`./${e}.json`);s.libraryCode=i,n.Utils.Lsi.setDefaultLsi(i,{en:o});const u=s},24:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});var n=r(94),o=r(12)
;const i=o.Z.TAG+"Routes.",s={...o.Z,TAG:i,
Css:n.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_homework_maing01-hi/uu_homework_maing01-hi@0.1.0")}},280:(e,t,r)=>{
var n=r(145),o="undefined"!=typeof document,i=((n?n.uri:o&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),s="/0.0.0/"
;(i=i.split(/\//).slice(0,-1).join("/")+"/").substr(-7)===s&&(i=i.substr(0,i.length-7)+"/0.1.0/"),r.p=i,e.exports=r(21);var u=e.exports
;u&&"object"==typeof u&&("version"in u||Object.defineProperty(u,"version",{configurable:!0,value:"0.1.0"}),"name"in u||Object.defineProperty(u,"name",{configurable:!0,
value:"uu_homework_maing01-hi".split(/[\/\\]/).pop()}),"namespace"in u||Object.defineProperty(u,"namespace",{configurable:!0,value:"UuHomework"}))},602:(e,t,r)=>{"use strict"
;var n,o=(n=r(321))&&"object"==typeof n&&"default"in n?n.default:n;function i(e){return i.warnAboutHMRDisabled&&(i.warnAboutHMRDisabled=!0,
console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),
o.Children.only(e.children)}i.warnAboutHMRDisabled=!1;var s=function e(){return e.shouldWrapWithAppContainer?function(e){return function(t){return o.createElement(i,null,o.createElement(e,t))}
}:function(e){return e}};s.shouldWrapWithAppContainer=!1;t.zj=i},394:(e,t,r)=>{var n={"./cs.json":[27,27],"./en.json":[823]};function o(e){if(!r.o(n,e))return Promise.resolve().then((()=>{
var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=n[e],o=t[0];return Promise.all(t.slice(1).map(r.e)).then((()=>r.t(o,19)))}o.keys=()=>Object.keys(n),o.id=394,
e.exports=o},145:t=>{"use strict";t.exports=e},321:e=>{"use strict";e.exports=u},918:e=>{"use strict";e.exports=r},94:e=>{"use strict";e.exports=t},834:e=>{"use strict";e.exports=n},389:e=>{
"use strict";e.exports=a},763:e=>{"use strict";e.exports=o},781:e=>{"use strict";e.exports=i},923:e=>{"use strict";e.exports=s},119:e=>{function t(){
return e.exports=t=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e
},e.exports.__esModule=!0,e.exports.default=e.exports,t.apply(this,arguments)}e.exports=t,e.exports.__esModule=!0,e.exports.default=e.exports},823:e=>{"use strict"
;e.exports=JSON.parse('{"appName":"Application uuHomework","About":{"header":"About application uuHomework","creatorsHeader":"Application creators","termsOfUse":"Terms of use"},"AboutContent":{"content":"<uu5string/>Demo application is a template for developing new applications.","technologiesContent":"<uu5string/>Other used technologies: <Uu5Elements.Link href=\'http://www.w3schools.com/html/default.asp\' target=\'_blank\'>Html5</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/css/default.asp\' target=\'_blank\'>CSS</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/js/default.asp\' target=\'_blank\'>JavaScript</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://getbootstrap.com\' target=\'_blank\'>Bootstrap</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://reactjs.org\' target=\'_blank\'>React</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://www.ruby-lang.org\' target=\'_blank\'>Ruby</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://puma.io\' target=\'_blank\'>Puma</Uu5Elements.Link> a <Uu5Elements.Link href=\'https://www.docker.com\' target=\'_blank\'>Docker</Uu5Elements.Link>. Application is operated in the <Uu5Elements.Link href=\'https://plus4u.net\' target=\'_blank\'>Plus4U</Uu5Elements.Link> internet service with the usage of <Uu5Elements.Link href=\'https://azure.microsoft.com\' target=\'_blank\'>Microsoft Azure</Uu5Elements.Link> cloud."},"ControlPanel":{"rightsError":"You do not have sufficient rights to display this component.","btNotConnected":"The application is not connected to a Business Territory."},"Home":{"welcome":"Welcome","intro":"<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of using. For application developing purposes they are suitable for modifying, copying and deleting. More about uuApp Structure see documentation&nbsp; <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuAppDevKit</Uu5Elements.Link>.","clientSide":"<uu5string/>Libraries <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/05ecbf4e8bca405290b1a6d4cee8813a/book\\" target=\\"_blank\\">uu5</Uu5Elements.Link> and <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/83c1406c4fc541dba975941424106318/book\\" target=\\"_blank\\">uuPlus4U5</Uu5Elements.Link> are used for developing of client side.","serverSide":"<uu5string/>It is necessary to initialize application workspace for running server side. See manual <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuApp Template Developer Guide</Uu5Elements.Link>"},"InitAppWorkspace":{"notAuthorized":"You do not have sufficient rights to use the application.","formHeader":"Initialize uuApp","formHeaderInfo":"<uu5string/>Your uuApp is running, but requires initialization. If you need help with filling up this form, see\\n<Uu5Elements.Link target=\\"_blank\\" href=\\"#\\">Documentation</Uu5Elements.Link>.","notAuthorizedForInit":"The application is running but it was not initialized yet and you do not have sufficient rights to do so.","uuBtLocationUriLabel":"uuBusinessTerritory location","uuBtLocationUriInfo":"Uri of the uuBt location where AWSC will be created","nameLabel":"Name","initialize":"Initialize"},"Menu":{"home":"Welcome","about":"About Application","shoppingListDetail":"Shopping List Detail"}}')
}},d={};function g(e){var t=d[e];if(void 0!==t)return t.exports;var r=d[e]={exports:{}};return m[e](r,r.exports,g),r.exports}return g.m=m,g.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
;return g.d(t,{a:t}),t},c=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,g.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e
;if(16&t&&"function"==typeof e.then)return e}var r=Object.create(null);g.r(r);var n={};l=l||[null,c({}),c([]),c(c)]
;for(var o=2&t&&e;"object"==typeof o&&!~l.indexOf(o);o=c(o))Object.getOwnPropertyNames(o).forEach((t=>n[t]=()=>e[t]));return n.default=()=>e,g.d(r,n),r},g.d=(e,t)=>{
for(var r in t)g.o(t,r)&&!g.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},g.f={},g.e=e=>Promise.all(Object.keys(g.f).reduce(((t,r)=>(g.f[r](e,t),t)),[])),g.u=e=>"chunks/index/"+e+"-"+{
27:"a3cc7d4485aa7d52c8e7",180:"254149fe7a5838b0c24f",327:"406e01cf753ed47cec0b",651:"b0fb2389c35b74447237",701:"15ae3d456b2958fba944"}[e]+".min.js",
g.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),p={},g.l=(e,t,r,n)=>{if(p[e])p[e].push(t);else{var o,i;if(void 0!==r)for(var s=document.getElementsByTagName("script"),u=0;u<s.length;u++){
var a=s[u];if(a.getAttribute("src")==e){o=a;break}}o||(i=!0,(o=document.createElement("script")).charset="utf-8",o.timeout=120,g.nc&&o.setAttribute("nonce",g.nc),o.src=e,
0!==o.src.indexOf(window.location.origin+"/")&&(o.crossOrigin="anonymous")),p[e]=[t];var l=(t,r)=>{o.onerror=o.onload=null,clearTimeout(c);var n=p[e];if(delete p[e],
o.parentNode&&o.parentNode.removeChild(o),n&&n.forEach((e=>e(r))),t)return t(r)},c=setTimeout(l.bind(null,void 0,{type:"timeout",target:o}),12e4);o.onerror=l.bind(null,o.onerror),
o.onload=l.bind(null,o.onload),i&&document.head.appendChild(o)}},g.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),
Object.defineProperty(e,"__esModule",{value:!0})},g.p="",(()=>{var e={826:0};g.f.j=(t,r)=>{var n=g.o(e,t)?e[t]:void 0;if(0!==n)if(n)r.push(n[2]);else{var o=new Promise(((r,o)=>n=e[t]=[r,o]))
;r.push(n[2]=o);var i=g.p+g.u(t),s=new Error;g.l(i,(r=>{if(g.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var o=r&&("load"===r.type?"missing":r.type),i=r&&r.target&&r.target.src
;s.message="Loading chunk "+t+" failed.\n("+o+": "+i+")",s.name="ChunkLoadError",s.type=o,s.request=i,n[1](s)}}),"chunk-"+t,t)}};var t=(t,r)=>{var n,o,[i,s,u]=r,a=0;if(i.some((t=>0!==e[t]))){
for(n in s)g.o(s,n)&&(g.m[n]=s[n]);if(u)u(g)}for(t&&t(r);a<i.length;a++)o=i[a],g.o(e,o)&&e[o]&&e[o][0](),e[o]=0
},r=this.__webpack_jsonp_uu_homework_maing01_hi_0_1_0_index=this.__webpack_jsonp_uu_homework_maing01_hi_0_1_0_index||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),g(280)})()));